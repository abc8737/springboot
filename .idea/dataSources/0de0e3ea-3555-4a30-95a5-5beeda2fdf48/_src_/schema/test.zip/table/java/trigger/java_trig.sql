CREATE TRIGGER java_trig
AFTER UPDATE ON java
FOR EACH ROW
  BEGIN
	INSERT INTO testTrig (action, time)
VALUES
	('updating', SYSDATE());


END;
